package problem1;

public class StudentTest {
	public static void main(String[] args) {
		Student s = new Student("Merey" , 2) ;
		System.out.println(s);
		s.incrTheYearOfStudy();
		System.out.println(s); 
	}
}
