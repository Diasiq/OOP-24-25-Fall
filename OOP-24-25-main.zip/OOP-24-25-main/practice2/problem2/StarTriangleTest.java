package problem2;

public class StarTriangleTest {
	public static void main(String[] args) {
		StarTriangle small = new StarTriangle(3);
		System.out.print(small.toString());
	}
}
