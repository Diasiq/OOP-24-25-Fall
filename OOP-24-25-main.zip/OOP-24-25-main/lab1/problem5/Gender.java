package problem5;

public enum Gender {
	B , G ; 
}
