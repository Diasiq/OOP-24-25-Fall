package problem2;

public enum Direction {
	FOOTBALL , VOLLEYBALL , BASKETBALL , UNKNOWN ; 
}
